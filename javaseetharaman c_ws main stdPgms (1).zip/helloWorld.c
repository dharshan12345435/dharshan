void main()
{
	printf("hello");
}
